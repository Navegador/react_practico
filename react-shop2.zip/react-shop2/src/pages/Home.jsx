import React from 'react';
import ProductList from '../containers/ProductList';

const Home = () => {
	return (
		<div className="Home">
			<ProductList />
		</div>
	);
}

export default Home;
